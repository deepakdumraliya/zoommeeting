<?php
//require_once 'vendor/autoload.php';
require_once "class-db.php";
define('BASE_URL','http://test-bh.potenzaglobalsolutions.com/zoommeeting/');
define('CLIENT_ID', 'XzKIslF8R9iW3JVgcxtFnQ');
define('CLIENT_SECRET', 'vEayAPlC7lpOwhaU0AWk7BS2toT3DJnJ');
define('REDIRECT_URI', BASE_URL.'/get_token.php');

